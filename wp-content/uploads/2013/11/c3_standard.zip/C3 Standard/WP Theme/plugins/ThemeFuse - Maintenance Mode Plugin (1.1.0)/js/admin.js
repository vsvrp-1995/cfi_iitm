jQuery(function(){
    jQuery("#tf_maintenance_date").datetimepicker();
});