<?php function tfuse_create_newspromo_page() { ?>

<iframe id="newspromo_iframe" src="http://themefuse.com/pages/newspromo/index.php" width="780" height="760" scrolling="auto" frameBorder="0"></iframe>

<?php } ?>