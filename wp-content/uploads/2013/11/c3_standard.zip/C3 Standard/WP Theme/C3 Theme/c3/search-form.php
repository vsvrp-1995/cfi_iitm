<div class="widget">
	<div class=" widget_search">

        <h3><?php _e('Search', 'tfuse'); ?>:</h3>
        <form method="get" id="searchform" action="<?php bloginfo('url'); ?>">
            <input type="text" name="s" class="stext" value="type and then press enter" onfocus="if (this.value == 'type and then press enter') {this.value = '';}" onblur="if (this.value == '') {this.value = 'type and then press enter';}" />
        </form>
        
    </div>
</div>
