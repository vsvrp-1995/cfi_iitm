Hi,


Thanks a lot for deciding on Clean Classy Corporate Standard theme. By Buying one of our 
themes you have access to our AfterCare Support Center as follows:


Online Documentation (for WP)- http://themefuse.com/wp-docs/clean-classy-corporate/
WP Dedicated Support Forum - http://themefuse.com/forum/clean-classy-corporate-wp/
Answers to your questions - http://themefuse.com/faq/
Customization Team - http://themefuse.com/wordpress-professionals/


Read the docs and faq and if you still have issues installing or modifying the theme
come to our dedicated support forums. We would love to help you.


ThemeFuse Support Team